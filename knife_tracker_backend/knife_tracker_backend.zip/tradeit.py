import collections

# Fix para MutableSet (Python 3.11+)
if not hasattr(collections, "MutableSet"):
    from collections.abc import MutableSet
    collections.MutableSet = MutableSet

# Fix para MutableMapping (Python 3.11+)
if not hasattr(collections, "MutableMapping"):
    from collections.abc import MutableMapping
    collections.MutableMapping = MutableMapping

# Fix para MutableSequence (só por segurança)
if not hasattr(collections, "MutableSequence"):
    from collections.abc import MutableSequence
    collections.MutableSequence = MutableSequence
    
import httpx

BASE_URL = "https://tradeit.gg/api/v2/inventory/data"

async def fetch_items_TradeIt(subcategories: list[str]):
    items = []

    async with httpx.AsyncClient() as client:
        for sub in subcategories:
            url = f"{BASE_URL}?gameId=730&sortType=Price+-+low&searchValue={sub}&type=6&showTradeLock=true&onlyTradeLock=false&showUserListing=true&context=trade"
            r = await client.get(url, timeout=10)
            data = r.json()
            items.extend(data.get("items", []))

    return items
